<?php
$dir = 'Output';

// Ensure the directory exists
if (!is_dir($dir)) {
    die("The 'Output' directory does not exist. Run ScanHawk and try scanning an NFC card.");
}

$files = scandir($dir);
$files = array_diff($files, ['.', '..']); // Remove '.' and '..' from list
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File List - Output Directory</title>
    <style>
        body {
            font-family: 'Linux Libertine', 'Georgia', serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        h1 {
            font-size: 24px;
            color: #222;
        }
        table {
            width: 60%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            border: 1px solid #a2a9b1;
        }
        th, td {
            padding: 10px;
            border: 1px solid #a2a9b1;
        }
        th {
            background-color: #f8f9fa;
        }
        a {
            text-decoration: none;
            color: #0645ad;
        }
        a:hover {
            text-decoration: underline;
        }
        .button {
            padding: 5px 10px;
            margin: 2px;
            border: 1px solid #a2a9b1;
            background-color: #f8f9fa;
            cursor: pointer;
            font-size: 14px;
        }
        .button:hover {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <h1>Files in the "Output" Directory</h1>
    <table>
        <tr>
            <th>Filename</th>
            <th>Actions</th>
        </tr>
        <?php if (empty($files)): ?>
            <tr>
                <td colspan="2">No files found. Maybe try putting something in the folder, genius.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($files as $file): ?>
                <tr>
                    <td><?php echo htmlspecialchars($file); ?></td>
                    <td>
                        <a class="button" href="<?php echo $dir . '/' . urlencode($file); ?>" target="_blank">View</a>
                        <a class="button" href="<?php echo $dir . '/' . urlencode($file); ?>" download>Download</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </table>
</body>
</html>
